package com.mufiid.dicodingbajp.ui.tvshow

import com.mufiid.dicodingbajp.data.TvShowEntity

interface TvShowFragmentCallback {
    fun onShareClick(tvShow: TvShowEntity)
}
